/**
 * 
 */
/**
 * @author madnarii
 *
 */
module Mishelin {
}