package project.rank;

public interface MichelinRank {
	
	   String getRank(int score);
}
