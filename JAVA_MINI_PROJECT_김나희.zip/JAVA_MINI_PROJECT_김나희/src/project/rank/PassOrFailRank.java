package project.rank;

public class PassOrFailRank implements MichelinRank{

	@Override
	public String getRank(int score) {
		
		if(score >= 80)
			return "MICHELIN"; 			//종합 점수가 기준 점수 이상일 경우 MICHELIN 부여
		else return "BlueRibbon";		//점수 미달일 경우 BlueRibbon 부여
	}
}
