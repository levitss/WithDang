package project.rank;

public class MainRank implements MichelinRank{
	  @Override
	   public String getRank(int score) {
	      String rank;
	      //전문 분야일 경우 검정색 별점
	      if(score >= 95 && score <= 100)
	         rank = "★★★★★";
	      else if(score >= 90 && score <= 94)
	         rank = "★★★★";
	      else if(score >= 80 && score <= 89)
	         rank = "★★★";
	      else if(score >= 70 && score <= 79)
	         rank = "★★";             
	      else 
	         rank = "★";      
	      
	      return rank;
	   }

	


}
