package project.rank;

public class SubRank implements MichelinRank {

	  @Override
	   public String getRank(int score) {
	      String rank;
	      //전문 분야가 아닐 경우, 하얀색 별점
	      if(score >= 90 && score <= 100)
	         rank = "☆☆☆☆☆";
	      else if(score >= 80 && score <= 89)
	         rank = "☆☆☆☆";
	      else if(score >= 70 && score <= 79)
	         rank = "☆☆☆";      
	      else if(score >= 55 && score <= 69)
	         rank = "☆☆";         
	      else 
	         rank = "☆";
	      return rank;
	   }

	


}
