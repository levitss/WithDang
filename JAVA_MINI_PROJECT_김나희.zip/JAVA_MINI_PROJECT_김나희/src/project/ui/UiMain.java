package project.ui;

import project.michelinguide.Food;
import project.michelinguide.MichelinGuide;
import project.michelinguide.Restaurant;
import project.michelinguide.Score;
import project.michelinguide.view.MichelinGuideDisplay;
import project.utils.Constants;

public class UiMain {
		   
		   MichelinGuide michelinGuide= MichelinGuide.getInstance();
		   MichelinGuideDisplay michelinDisplay = new MichelinGuideDisplay();
		   Food korean;
		   Food chinese;
		   Food total;

		   public static void main(String[] args) {
	
			   
		      UiMain uiMain = new UiMain();
		      
		      uiMain.createFood();  			 //요리 종목 생성
		      uiMain.createRestaurant();         //대회 참가 생성
		      
		      String display = uiMain.michelinDisplay.getDisplay();
		      System.out.println(display);
		      
		   }
		   	//식당 리스트와 참가번호, 전문분야 생성
		   public void createRestaurant() {
		      Restaurant restaurant1 = new Restaurant("삼원가든", 1101, korean);
		      Restaurant restaurant2 = new Restaurant("홍콩반점", 1102, chinese);
		      Restaurant restaurant3 = new Restaurant("굽네", 1103, korean);
		      Restaurant restaurant4 = new Restaurant("에그드랍", 1104, korean);
		      Restaurant restaurant5 = new Restaurant("하이디라오", 1105,chinese);

		      
		      michelinGuide.addRestaurant(restaurant1);
		      michelinGuide.addRestaurant(restaurant2);
		      michelinGuide.addRestaurant(restaurant3);
		      michelinGuide.addRestaurant(restaurant4);
		      michelinGuide.addRestaurant(restaurant5);

		      
		      korean.attend(restaurant1);
		      korean.attend(restaurant2);
		      korean.attend(restaurant3);
		      korean.attend(restaurant4);
		      korean.attend(restaurant5);


		      
		      chinese.attend(restaurant1);
		      chinese.attend(restaurant2);
		      chinese.attend(restaurant3);
		      chinese.attend(restaurant4);
		      chinese.attend(restaurant5);
		      
		      total.attend(restaurant1);
		      total.attend(restaurant2);
		      total.attend(restaurant3);
		      total.attend(restaurant4);
		      total.attend(restaurant5);



		 
		      
		      //요리 종목 별 점수 입력
		      addScoreForRestaurant(restaurant1, korean, 88);
		      addScoreForRestaurant(restaurant1, chinese, 71);
		      addScoreForRestaurant(restaurant1, total, 69);
		      
		      addScoreForRestaurant(restaurant2, korean, 80);
		      addScoreForRestaurant(restaurant2, chinese, 97);
		      addScoreForRestaurant(restaurant2, total, 88);

		      addScoreForRestaurant(restaurant3, korean, 88);
		      addScoreForRestaurant(restaurant3, chinese, 65);
		      addScoreForRestaurant(restaurant3, total, 67);

		      
		      addScoreForRestaurant(restaurant4, korean, 99);
		      addScoreForRestaurant(restaurant4, chinese, 91);
		      addScoreForRestaurant(restaurant4, total, 96);


		      addScoreForRestaurant(restaurant5, korean, 66);
		      addScoreForRestaurant(restaurant5, chinese, 96);
		      addScoreForRestaurant(restaurant5, total, 67);



		   }

		   private void addScoreForRestaurant(Restaurant restaurant, 
		                           Food food, int score) {
		      Score score1 = new Score(restaurant.getRestaurantNo(), food, score);
		      restaurant.addFoodScore(score1); 
		   }

		   public void createFood() {
		      korean = new Food(Constants.KOREAN, "한식 ");
		      chinese = new Food(Constants.CHINESE, "중식 ");
		      total = new Food(Constants.TOTAL, "종합 ");
		      
		      total.setRankType(Constants.POF_TYPE);

		      michelinGuide.addFood(korean);
		      michelinGuide.addFood(chinese);
		      michelinGuide.addFood(total);


		   }
		
}
