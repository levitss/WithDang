package project.utils;

public class Constants {
		   
		   public static final int KOREAN = 1001;     //한식
		   public static final int CHINESE = 1002;    //중식
		   public static final int TOTAL = 1003;      //종합평가

		   
		   public static final int MAIN_TYPE = 0;     //★ 전문분야 평가 별점
		   public static final int SUB_TYPE = 1;      //☆ 비전문분야 평가 별점
		   public static final int POF_TYPE = 2;      //MICHELIN 합격 여부

		
}
