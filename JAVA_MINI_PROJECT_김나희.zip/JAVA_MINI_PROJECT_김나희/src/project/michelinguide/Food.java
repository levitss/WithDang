package project.michelinguide;
import java.util.ArrayList;

public class Food {


	   private int foodTypeNo;         //종목 고유번호 
	   private String foodType;       //종목 이름
	   private int rankType;         //랭크 부여 방식
	   // 참가 신청한 식당들
	   private ArrayList<Restaurant> restaurants = new ArrayList<>();
	   
	   public Food(int foodTypeNo, String foodType) {
	      this.foodTypeNo = foodTypeNo;
	      this.foodType = foodType;
	   }
	   public Food() {
		   
	   }
	   public int getFoodTypeNo() {
		return foodTypeNo;
	}
	public void setFoodTypeNo(int foodTypeNo) {
		this.foodTypeNo = foodTypeNo;
	}
	public String getFoodType() {
		return foodType;
	}
	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}
	public int getRankType() {
		return rankType;
	}
	public void setRankType(int rankType) {
		this.rankType = rankType;
	}
	public ArrayList<Restaurant> getRestaurants() {
		return restaurants;
	}
	public void setRestaurants(ArrayList<Restaurant> restaurants) {
		this.restaurants = restaurants;
	}


		//참가 신청
	   public void attend(Restaurant restaurant) {       
	      restaurants.add(restaurant);
	   }
	   
	   
	



}
