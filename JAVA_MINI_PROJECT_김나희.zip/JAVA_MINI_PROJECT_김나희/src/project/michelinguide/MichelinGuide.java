package project.michelinguide;
import java.util.ArrayList;

public class MichelinGuide {

	   private static MichelinGuide instance = new MichelinGuide();
	   private MichelinGuide() {}

	   public static MichelinGuide getInstance() {
	      if(instance == null)					//안전하게 null check
	         instance = new MichelinGuide();	//값이 없으면 생성
	      return instance;				//있다면 그대로 instance return
	   }
	   	   //식당 전문분야 넣을 수 있도록 Arraylist 생성
	   private ArrayList<Restaurant> restaurants = new ArrayList<>();
	   private ArrayList<Food> foods = new ArrayList<>();
	   
	   public ArrayList<Restaurant> getRetaurants() {
		return restaurants;
	}
	   public ArrayList<Food> getFoods() {
		return foods;
	}

	public void setRetaurants(ArrayList<Restaurant> retaurants) {
		this.restaurants = retaurants;
	}


	public void setFoods(ArrayList<Food> foods) {
		this.foods = foods;
	}
	
	public void addRestaurant(Restaurant restaurant) {
		restaurants.add(restaurant);
	}
	
	public void addFood(Food food) {
		foods.add(food);
	}

	public static void setInstance(MichelinGuide instance) {
		MichelinGuide.instance = instance;
	}
	   
	   
	

}
