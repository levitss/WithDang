package project.michelinguide;

public class Score {
	   private int restaurantNo;       //참가 번호
	   private Food food;    		  //종목
	   private int Score;            //점수
	   
	   public Score(int restaurantNo, Food food, int score) {
	      this.restaurantNo = restaurantNo;
	      this.food = food;
	      this.Score = score;
	   }



	public int getRestaurantNo() {
		return restaurantNo;
	}

	public Food getFood() {
		return food;
	}

	public int getScore() {
		return Score;
	}
	   
	   

	   
	   

}
