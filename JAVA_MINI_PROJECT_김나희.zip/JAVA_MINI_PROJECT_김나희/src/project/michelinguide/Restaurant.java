package project.michelinguide;
import java.util.ArrayList;

public class Restaurant {
	
	   private String restaurantName;         //이름
	   private int restaurantNo;            //참가번호
	   private Food mainFood = new Food();      //전문 요리 분야
	   private ArrayList<Score> scores = new ArrayList<>();   //점수 리스트
	   
	   public Restaurant(String restaurantName, int restaurantNo, Food mainFood) {
	      this.restaurantName = restaurantName;
	      this.restaurantNo = restaurantNo;		
	      this.mainFood = mainFood;	 
	   }

	   public String getRestaurantName() {
		return restaurantName;
	}

	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}

	public int getRestaurantNo() {
		return restaurantNo;
	}

	public void setRestaurantNo(int restaurantId) {
		this.restaurantNo = restaurantNo;
	}

	public Food getMainFood() {
		return mainFood;
	}

	public void setMainFood(Food mainFood) {
		this.mainFood = mainFood;
	}

	public void setScores(ArrayList<Score> scores) {
		this.scores = scores;
	}

	   public void addFoodScore(Score score) {
	      scores.add(score);
	   }
	   
	   public ArrayList<Score> getScores() {
	      return scores;
	   }

	public static Restaurant getInstance() {
		return null;
	}

	   
	
}
