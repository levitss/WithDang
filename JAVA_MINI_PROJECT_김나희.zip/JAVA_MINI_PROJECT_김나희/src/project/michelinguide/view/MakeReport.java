package project.michelinguide.view;

public interface MakeReport {
	void makeHeader();
	void makeBody();
	void makeFooter();
	

}
