package project.michelinguide.view;

import java.util.ArrayList;

import project.michelinguide.Food;
import project.michelinguide.MichelinGuide;
import project.michelinguide.Restaurant;
import project.michelinguide.Score;
import project.rank.MainRank;
import project.rank.MichelinRank;
import project.rank.PassOrFailRank;
import project.rank.SubRank;
import project.utils.Constants;

public class MichelinGuideDisplay {
	   MichelinGuide michelinGuide = MichelinGuide.getInstance();
	   
	   public static final String TITLE = "미슐랭 가이드 평가 결과 >>> \n";
	   public static final String LINE = "-----------------------------------------------------\n";
	   public static final String HEADER ="식당\t     참가번호\t 전문 \t  점수      평가  \n";
	   public static final String LINE2 = "=====================================================\n";
	   
	   private StringBuffer buffer = new StringBuffer();
	   
	   public void makeHeader (Food food) {
	      buffer.append("\t" + food.getFoodType());
	      buffer.append(MichelinGuideDisplay.TITLE);
	      buffer.append(MichelinGuideDisplay.LINE);
	      buffer.append(MichelinGuideDisplay.HEADER);
	      buffer.append(MichelinGuideDisplay.LINE);
	   }
	   
	   public String getDisplay() {
	      ArrayList<Food> foods = michelinGuide.getFoods();
	      
	      for(Food food : foods) {
	         makeHeader(food);
	         makeBody(food);
	         makefooter(food);
	      }
	      return buffer.toString();
	   }

	   private void makefooter(Food food) {
	      buffer.append(MichelinGuideDisplay.LINE2);
	      buffer.append("\n");
	   }
	   //5개의 레스토랑 정보 Arraylist로 
	   private void makeBody(Food food) {
	      ArrayList<Restaurant> restaurants = food.getRestaurants();
	      
	      for(int i=0;  i < restaurants.size();  i++) {
	         Restaurant restaurant = restaurants.get(i);
	         buffer.append(restaurant.getRestaurantName());
	         buffer.append("\t     ");
	         
	         buffer.append(restaurant.getRestaurantNo());
	         buffer.append("        ");
	         
	         buffer.append(restaurant.getMainFood().getFoodType());
	         buffer.append("     ");
	         
	         getScoreRank(restaurant, food);      //레스토랑 별 해당 음식 종목 Rank
	         
	         buffer.append("\n");
	      }
	      
	   }

	   private void getScoreRank(Restaurant restaurant, Food food) {
	      ArrayList<Score> scoreList = restaurant.getScores();
	      int mainFoodId = restaurant.getMainFood().getFoodTypeNo();
	      
	      //미쉐린 평가 클래스들 
	      MichelinRank[] michelinRanks = 
	            {new MainRank(), new SubRank(), new PassOrFailRank()};   
	      
	      //점수들
	      for(int i = 0; i < scoreList.size(); i++) {
	         Score score = scoreList.get(i);
	         //현재 학점을 산출할 과목
	         if(score.getFood().getFoodTypeNo() == food.getFoodTypeNo()) {
	            String rank;
	         // 전문부문 평가
	            if(score.getFood().getFoodTypeNo() == mainFoodId)  
	            	
	               rank =michelinRanks[Constants.MAIN_TYPE].getRank(score.getScore());
	         // 전문분야가 아닌 경우                        
	            else
	               rank = michelinRanks[Constants.SUB_TYPE]      
	                                 .getRank(score.getScore());
	            
	         // 종합 결과로 MICHELIN과 BlueRibbon 으로 부여
	            if(food.getFoodTypeNo() == Constants.TOTAL)
	            	rank = michelinRanks[Constants.POF_TYPE].getRank(score.getScore());
	            
	            buffer.append(score.getScore());
	            buffer.append("  \t   ");
	            buffer.append(rank);
	         }
	      }
	      
	      
	   }
	   
	


}
