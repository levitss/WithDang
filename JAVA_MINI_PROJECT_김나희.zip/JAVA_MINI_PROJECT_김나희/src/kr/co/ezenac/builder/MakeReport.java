package kr.co.ezenac.builder;

public interface MakeReport {
	void makeHeader();
	void makeBody();
	void makeFooter();
	

}
