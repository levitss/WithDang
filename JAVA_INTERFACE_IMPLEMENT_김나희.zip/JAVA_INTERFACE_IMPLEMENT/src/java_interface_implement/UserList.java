package java_interface_implement;

public interface UserList<T> {
	//추가
    void add(T t);
    //해당 인덱스에 추가
    void insert(int index, T t);
    //전체 삭제
    void clear();
    //해당 인덱스 회원 삭제 후 빈 곳부터 shift 정렬
    boolean delete(T t);
    //해당 인덱스 회원 삭제
    boolean deleteUser(int index);
    //인덱스로 찾기
    T get(int index);
    //인덱스를 찾기
    int indexOf(T t);
    //리스트가 비어 있는지 참 거짓으로 반환
    boolean isEmpty();
    //유효한 요소인지 참 거짓으로 반환
    boolean contains(T t);
    //리스트의 크기 반환 기능
    int size();
    //내용 전체 출력 기능
    void printAll();
}
