package java_interface_implement;

public class UserInfoTest {
	public static void main(String[] args)  {
		 
        UserList<Integer> userNum = new UserInfo<>();
        userNum.add(1);
        userNum.add(2);
        userNum.add(9);
        userNum.add(4);
        userNum.add(6);
        userNum.add(7);
        userNum.add(8);
        userNum.add(3);
        userNum.add(0);

        System.out.println("▼ 초기 회원 번호 리스트 ▼");
            //5번째에 5번 회원 번호 추가
        userNum.insert(5,5);
        	//초기 회원 번호 전체 보여주기
        userNum.printAll();
            //6번 회원 번호를 삭제하면서 앞쪽으로 정렬
        userNum.delete(6);
            //8번째 인덱스 회원 번호 삭제(0번)
        userNum.deleteUser(8);
        System.out.println();
        System.out.println();
        System.out.println("▼ 현재 유효한 회원 번호 리스트 ▼ 회원 명 수 : " + userNum.size());
        //남은 회원 출력
        userNum.printAll();
        System.out.println();
        System.out.println("\n[ 2번 회원이 유효회원인지 검색 ] " + userNum.contains(2) 
		+ "\n 2번 회원의 index 번호 : " + userNum.indexOf(2) );
        UserList<String> userName = new UserInfo<>();
        System.out.println();
            //회원 이름 추가
        userName.add("김쫑이");
        userName.add("곤푸름");
        userName.add("강동원");
        userName.add("잠수만");
        	//특정 인덱스에 회원 명단 추가
        userName.insert(1, "쪼리");
        userName.insert(4, "강아지");
        	//특정 인덱스 삭제
        userName.deleteUser(2);		//곤푸름 회원 삭제
        System.out.println("▼ 현재 유효한 회원 명단 리스트 ▼ 회원 명 수 : " + userName.size());
        userName.printAll();
        System.out.println();
        System.out.println("\n[ 3번 째 index 회원명 ] " + userName.get(3) );
        	//회원 명단 전체 삭제
        System.out.println();
        System.out.println("▼ 회원 명단 전체 삭제 결과 ▼");
        userName.clear();
        userName.printAll();
        System.out.println();
        	//회원 번호 전체삭제
        System.out.println("▼ 회원 번호 전체 삭제 결과 ▼");
        userNum.clear();
        userNum.printAll();
        }
}
