package java_interface_implement;

import java.util.Arrays;

public class UserInfo<T> implements UserList<T>{

    private static final int DEAFULT_SIZE = 70; //사이즈 70 디폴트 값으로 선언
    private T[] arrays;               
    private int size;                   
    public UserInfo(){
        this.size = 0;
        this.arrays = (T[])new Object[DEAFULT_SIZE];    // arrays에 최대 크기를 정의
    }
    
    @Override
    public void add(T t) {           
        if(this.size == this.arrays.length)        //size가 디폴트로 정의된 길이와 같으면
            this.arrays = Arrays.copyOf(this.arrays,this.size*2);  //배열의 길이를 2배로 키운
        this.arrays[this.size] = t;        
        this.size += 1;                      //동적으로 맨 뒤부터 단계적으로 1씩 추가
    }

    @Override
    public void insert(int index, T t) {            //정의한 인덱스에 추가
        if(this.size == this.arrays.length)
            this.arrays = Arrays.copyOf(this.arrays,this.size*2);

        for(int i = size -1; i >= index; i--)
            this.arrays[i + 1] = this.arrays[i];  //중간 인덱스에 인서트하게되면 차례대로 뒤로 밀리되게 됨
        this.arrays[index] = t;
        this.size++;                            
    }

    @Override
    public void clear() {		//삭제
        this.size = 0;
        this.arrays = (T[])new Object[DEAFULT_SIZE];  //초기화

    }

    @Override
    public boolean delete(T t) {              //해당 인덱스 삭제하면서 중간에 빈 값에 앞쪽으로 당겨오기
        for (int i = 0; i < this.size; i++) {
            if (this.arrays[i].equals(t)) {           //같은 것이 있는지 체크
                for (int j = i; j < this.size - 1; j++) {
                	this.arrays[j] = this.arrays[j + 1];    // 왼쪽으로 정렬
                }
                this.size--;
                return true;
            }
        }return false;
    }
    @Override
    public boolean deleteUser(int index) {               
        if(index < 0 || index > this.size - 1){
            return false;
        }									//특정 회원 삭제
        for(int i = index; i <this.size - 1; i++){
            this.arrays[i] = this.arrays[i+1];
        }
        this.size--;
        return true;
    }

    @Override
    public T get(int index) {
        if(index < 0 || index > this.size - 1)
        {              						//인덱스 범위를 벗어나면 처리되지 않도록 예외처리
            throw new IndexOutOfBoundsException();
        }
        return this.arrays[index];
    }

    @Override
    public int indexOf(T t) {
        for(int i = 0; i <this.size; i++){
            if(this.arrays[i].equals(t)){
                return i;
            }
        }
        return -1;              			//찾는 인덱스가 없기때문에 -1 반환
    }

    @Override
    public boolean isEmpty() {
        return this.size == 0;             	//리스트가 비었다면 true 반환
    }

    @Override
    public boolean contains(T t) {
        for(int i =0; i < this.size; i++){
            if(this.arrays[i].equals(t)){
                return true;
            }
        }
        return false;
    }
    @Override
    public int size() {
        return this.size;
    }
    @Override
    public void printAll() {
        if(isEmpty()){			//내용이 비었다면
            System.out.println("내용이 없습니다.");		//를 출력
        } for(int i =0; i < this.size; i++){
            System.out.print(arrays[i] + " ");
        }
    }
}
